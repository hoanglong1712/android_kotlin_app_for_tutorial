package com.lehoanglong.tinhsinhnhattheongay

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private var tv_NgayDuocChon: TextView? = null
    private var tv_KetQua: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn_ChonNgay: Button = findViewById(R.id.btnChonNgay)
        tv_NgayDuocChon = findViewById(R.id.tvNgayDuocChon)
        tv_KetQua = findViewById(R.id.tvKetQua)

        btn_ChonNgay.setOnClickListener{
            fn_btn_ChonNgay()
        }
    }

    private fun fn_btn_ChonNgay(){

        val lich = Calendar.getInstance()
        val nam = lich.get(Calendar.YEAR)
        val thang = lich.get(Calendar.MONTH)
        val ngay = lich.get(Calendar.DAY_OF_MONTH)

        val ngay_chon = DatePickerDialog(this,
            DatePickerDialog.OnDateSetListener { view, nam_, thang_, ngay_ ->
                Toast.makeText(this, "$nam_, ${thang_+1}",
                    Toast.LENGTH_LONG).show()
                val ngayDuocChon = "$ngay_/${thang_+1}/$nam_"
                tv_NgayDuocChon?.text = ngayDuocChon

                val mau = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
                val homDo = mau.parse(ngayDuocChon)
                homDo?.let {
                    val phut = homDo.time / 60000
                    val homNay = mau.parse(mau.format(System.currentTimeMillis()))

                    homNay?.let{
                        val saiKhac = homNay.time / 60000 - phut
                        tv_KetQua?.text = saiKhac.toString()
                    }
                }

            }, nam, thang, ngay
        )

        ngay_chon.datePicker.maxDate = System.currentTimeMillis() - 86400
        ngay_chon.show()
    }
}